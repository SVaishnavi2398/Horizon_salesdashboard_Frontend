import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
//import { Console } from 'console';
import { DataService } from 'src/app/service/data.service';
import { TokenService } from 'src/app/service/token.service';
import Swal from 'sweetalert2';
import { Invoicedetails } from './invoice-details.multiple.model';

@Component({
  selector: 'app-invoice-details-multiple',
  templateUrl: './invoice-details-multiple.component.html',
  styleUrls: ['./invoice-details-multiple.component.scss']
})
export class InvoiceDetailsMultipleComponent implements OnInit {

  companylistArr :any;
  invoicedetails = new Invoicedetails;
  error = new Invoicedetails;
  invoice = new Invoicedetails;
  gstArr: any;
  clientsArr: any;
  form: FormGroup;
  data: any;
  sales = new Invoicedetails;
  empList : any[]=[];
  tax_amt: any[]=[];
  array: any[]=[];
  sales_id :any[]=[];
  flat_no :any[]=[];
  building_name:any[]=[];
  payout_value :any[]=[];
  consideration_value :any[]=[];
  taxable_amt:any[]=[];
  wing:any[]=[];
  booking_date :any[]=[];
  project_name :any[]=[];
  CGST: number;
  total_taxableamt: any;
  taxablearr: any;
  sumNumber: any;
  value: any;
  tax: any[]=[];
  received_amt:any[]=[];
  tds_rate:any[]=[];
  invoicestatusArr: any;
  data1: any;
  toastr: any;

  constructor(
    private dataservice:DataService,
    private route: Router,
    private Token:TokenService
  ) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      passenger: new FormArray([
        new FormGroup({
          taxable_amt: new FormControl(''),
          received_amt:new FormControl(''),
          tds_rate:new FormControl('')
        // flat_no: new FormControl(''),
        // building_name: new FormControl(''),
        // consideration_value: new FormControl(''),
        // payout_value: new FormControl(''),
        // client_id: new FormControl(''),
        // sales_id: new FormControl('')
    

        })
      ])
    });
this.bmi();
  
    this.getCompanyData();
    this.getInvoicestatus();
  }
  
  getInvoicestatus(){
    this.dataservice.getInvoiceStatus().subscribe(res=>{
      this.invoicestatusArr=res;
    })
  }
  
  getCompanyData(){
    this.dataservice.getCompany().subscribe(res=>{
      this.companylistArr=res;
      
    })
  }

  getState1(event){
    var compny_id = event.target.value; 
    this.dataservice.getCompanygst(compny_id).subscribe(res => {
      this.gstArr = res;
      this.invoicedetails.cgst= this.gstArr[0].cgst;
      this.invoicedetails.company_id= this.gstArr[0].debtor_company_det_id;
      var selectedOption = this.invoicedetails.cgst;
      this.value=this.gstArr[0].cgst.startsWith('27');
      this.bmi();

    this.dataservice.getclientid(compny_id).subscribe(res => {
      this.clientsArr = res;
    })
  })
}

get passenger(): FormArray {
  return this.form.get('passenger') as FormArray;
}

addPassenger() {
  this.passenger.push(
    new FormGroup({
      taxable_amt: new FormControl(''),
      received_amt:new FormControl(''),
      tds_rate:new FormControl('')
      // flat_no: new FormControl(''),
      // building_name: new FormControl(''),
      // consideration_value: new FormControl(''),
      // payout_value: new FormControl(''),
      // client_id: new FormControl(''),
      // sales_id: new FormControl('')

    })
  );
console.log(this.passenger.value);
}




getState2(event){
  
  var client_id = event.target.value;
  // console.log(client_id);
    this.dataservice.getsalesdetails(client_id).subscribe(res => {
      console.log(res);
    this.data = res;
    this.sales.client_id = client_id;
    this.sales= this.data;
    this.empList.push(this.sales);
      this.array = this.empList;
      
      for(var i=0; i<this.array.length; i++){
        this.project_name[i]= this.array[i][0].project_name;
        this.sales_id[i]= this.array[i][0].sales_id;
        this.flat_no[i]= (this.array[i][0].flat_no);
        this.wing[i]= (this.array[i][0].wing);
        this.booking_date[i]= (this.array[i][0].booking_date);
        this.building_name[i]= (this.array[i][0].building_name);
        this.payout_value[i]= (this.array[i][0].payout_value);
        this.consideration_value[i]= (this.array[i][0].consideration_value);
        this.taxable_amt[i] = (this.consideration_value[i] * this.payout_value[i]) / 100;
        
      }
     // console.log(this.taxable_amt);
      this.bmi();
    })
}
editRow(group: FormGroup) {
  group.get('isEditable').setValue(true);
}


getstate3(event){
   this.taxablearr =this.form.value;
   var amt = this.taxablearr.passenger;
   for(var i =0; i<amt.length; i++){
     this.tax_amt[i] = amt[i].taxable_amt;
   }
  
  //  this.invoicedetails.sumNumber = this.tax_amt.reduce((acc, cur) => acc + Number(cur), 0)
  //  console.log(this.invoicedetails.sumNumber);
  this.bmi();
 }

 bmi() {
  //console.log(this.tax_amt);
  //console.log(this.taxable_amt);
   for (var i=0; i<this.taxable_amt.length; i++){
       if(!(this.tax_amt[i])){
         this.tax[i]= this.taxable_amt[i];
       }
       else{
        this.tax[i]= this.tax_amt[i];
       }
   }

   
   this.invoicedetails.sumNumber = this.tax.reduce((acc, cur) => acc + Number(cur), 0)
   this.bmi1();
  if(this.value == true){
     var selectedOption = (Number(this.invoicedetails.sumNumber) * Number(9)) / 100;
     this.invoicedetails.cgst_amt = (Number(this.invoicedetails.sumNumber) * Number(9)) / 100;
     this.invoicedetails.sgst_amt = (Number(this.invoicedetails.sumNumber) * Number(9)) / 100;
     this.invoicedetails.igst_amt = 0;
     this.invoicedetails.total_gst_amt = Number(this.invoicedetails.cgst_amt) + Number(this.invoicedetails.sgst_amt);
     this.invoicedetails.total_invoice_amt = Number(this.invoicedetails.total_gst_amt) + Number(this.invoicedetails.sumNumber);
     this.bmi1();
    // return  (Number(this.invoicedetails.sumNumber) * Number(9)) / 100;
   }
   else{
     var selectedOption = 0;
     this.invoicedetails.cgst_amt = 0;
     this.invoicedetails.sgst_amt = 0;
     this.invoicedetails.igst_amt = (Number(this.invoicedetails.sumNumber) * Number(18)) / 100;
     this.invoicedetails.total_gst_amt = Number(this.invoicedetails.igst_amt);
     this.invoicedetails.total_invoice_amt = Number(this.invoicedetails.total_gst_amt) + Number(this.invoicedetails.sumNumber);
     this.bmi1();
     return 0;
   }


   }

   getstate4(event){
     this.invoicedetails.tds_rate = event.target.value;
     this.bmi1();
   }

   getstate5(event){
    this.invoicedetails.received_amt = event.target.value;
    this.bmi1();
  }

  
  bmi1() {
    this.invoicedetails.receivable_tds_amt = (Number(this.invoicedetails.sumNumber) * Number(this.invoicedetails.tds_rate)) / 100;
    this.invoicedetails.receivable_amt = Number(this.invoicedetails.total_invoice_amt) - Number(this.invoicedetails.receivable_tds_amt);
    this.invoicedetails.suspense_amt = Number(this.invoicedetails.receivable_amt) - Number(this.invoicedetails.received_amt); 
    this.invoicedetails.due_amt = Number(this.invoicedetails.receivable_amt); 

  }
  getstate6(event){
    this.invoicedetails.inv_status_id = event.target.value;
  }
  getstate7(event){
    this.invoicedetails.inv_submitted_date = event.target.value;
  }
  getstate8(event){
    this.invoicedetails.credit_note_amt = event.target.value;
  }
  getstate9(event){
    this.invoicedetails.invoice_num = event.target.value;
  }
  getstate10(event){
    this.invoicedetails.invoice_date = event.target.value;
  }

  submitInvoicedetails(){
    console.log(this.invoicedetails.sumNumber)
    this.invoicedetails.taxable_amt=this.invoicedetails.sumNumber;
    //console.log(this.invoicedetails);
    this.dataservice.registerinvoiceMultidetails(this.invoicedetails).subscribe(res=>{
     console.log('1',res);
      this.data1= res;


      for(var i=0; i<this.array.length; i++){
        this.invoice.invoice_multi_id = this.data1.invoice_multi_id;
        this.invoice.project_name= this.array[i][0].project_name;
        this.invoice.project_name = this.project_name[i];
        this.invoice.sales_id= this.array[i][0].sales_id;
        this.invoice.sales_id = this.sales_id[i];
        this.invoice.flat_no= (this.array[i][0].flat_no);
        this.invoice.wing= (this.array[i][0].wing);
        this.invoice.booking_date= (this.array[i][0].booking_date);
        this.invoice.building_name =(this.array[i][0].building_name);
        this.invoice.payout_value =(this.array[i][0].payout_value);
        this.invoice.consideration_value= (this.array[i][0].consideration_value);
        //this.invoice.taxable_amt = (this.consideration_value[i] * this.payout_value[i]) / 100;
        this.invoice.client_id= this.array[i][0 ].client_id;
        this.invoice.taxable_amt = this.tax[i];
        console.log('2',this.invoice);
        this.dataservice.registerSales(this.invoice).subscribe(
         
         data=>this.handleResponse(data),
         error=>this.handleError(error)
        );
      }
     
     
    })
    
  // this.registersalesclient();
  }

  handleResponse(data){
  
    if(data.client_id == this.invoice.client_id){
    this.Token.handle(data.access_token);
    Swal.fire('Added!', 'Invoice Details has been added.', 'success'); 
    this.route.navigateByUrl('/form/invoices/invoice/invoicemultipledetailslist');
    }
  }

   
  handleError(error){
    this.error = error.error.errors;
  }


  // registersalesclient(){
  //    this.dataservice.getlastinvoiceid().subscribe(res=>{
  //     this.data=res;
  //   console.log('4',res);
  //   console.log('5',this.tax);
  //   for(var i=0; i<this.array.length; i++){
  //     this.invoice.invoice_id = this.data1.invoice_id;
  //     this.invoice.project_name= this.array[i][0].project_name;
  //     this.invoice.project_name = this.project_name[i];
  //     this.invoice.sales_id= this.array[i][0].sales_id;
  //     this.invoice.sales_id = this.sales_id[i];
  //     this.invoice.flat_no= (this.array[i][0].flat_no);
  //     this.invoice.wing= (this.array[i][0].wing);
  //     this.invoice.booking_date= (this.array[i][0].booking_date);
  //     this.invoice.building_name =(this.array[i][0].building_name);
  //     this.invoice.payout_value =(this.array[i][0].payout_value);
  //     this.invoice.consideration_value= (this.array[i][0].consideration_value);
  //     //this.invoice.taxable_amt = (this.consideration_value[i] * this.payout_value[i]) / 100;
  //     this.invoice.client_id= this.array[i][0 ].client_id;
  //     this.invoice.taxable_amt = this.tax[i];
  //     console.log('2',this.invoice);
  //     this.dataservice.registerSales(this.invoice).subscribe(res=>{
  //       console.log('3',res);
  //     })
  //   }
  // })
    
  // }
}
