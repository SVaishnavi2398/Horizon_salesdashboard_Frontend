import { SearchinvoicedetailsPipe } from './searchinvoicedetails.pipe';

describe('SearchinvoicedetailsPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchinvoicedetailsPipe();
    expect(pipe).toBeTruthy();
  });
});
