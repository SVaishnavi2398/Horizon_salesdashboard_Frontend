export class Invoicedetails{
    invoice_id:any;
    sales_id : any;
    client_id : any;
    company_id : any ;
    invoice_num : any ;
    invoice_date : any ;
    payout_percentage : any ;
    taxable_amt : any ;
    cgst_amt : any ;
    sgst_amt : any ;
    igst_amt:any;
    total_gst_amt : any ;
    total_invoice_amt : any ;
    tds_rate : any ;
    receivable_tds_amt : any ;
    receivable_amt : any ;
    inv_status_id : any ;
    inv_submitted_date : any ;
    due_amt : any ;
    credit_note_amt : any;
    name:any;
    suspense_amt:any;
    received_amt:any;
    comments:any;
    user_id:any;
  cgst: any;
  flat_no:any;
  building_name:any;
  consideration_value:any;
  payout_value:any;
  flat_no1:any;
    
}



export class addDivisions {
}