import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from 'src/app/service/data.service';
import { Salesdetails } from '../salesdetails/salesdetails.model';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-editsalesdetails',
  templateUrl: './editsalesdetails.component.html',
  styleUrls: ['./editsalesdetails.component.scss']
})
export class EditsalesdetailsComponent implements OnInit {

  salesdetailsid:any;
  salesdetails= new Salesdetails;
  data:any;
  clientArr : any;
  projectArr : any;
  subprojectsArr : any;
  bookingstatusArr : any;
  channelpartnerArr : any;
  payoutstatusArr : any;
  usersArr : any;
  teamsArr : any;
  leadsourceArr : any;
  booking_date: any;
  newDate1: any;
  newDate2: any;

  constructor(
    private route:ActivatedRoute,
    private dataservice:DataService,
    private router: Router,
    private datePipe:DatePipe
  ) { }

  ngOnInit(): void {
    this.salesdetailsid=this.route.snapshot.params.id;
    this.getSalesdetailsData();
    this.getClientData();
    this.getProjectData();
    this.getSubprojectData();
    this.getBookingstatusData();
    this.getChannelpartnerData();
    this.getPayoutstatusData();
    this.getUserData();
    this.getTeamsData();
    this.getLeadsourceData();
  }

  getSalesdetailsData(){
    this.dataservice.getOneSalesdetails(this.salesdetailsid).subscribe(res=>{
      //console.log(res);
      this.data=res;
      this.salesdetails=this.data;
  })
  }

  getClientData(){
    this.dataservice.getClientList().subscribe(res=>{
      //console.log(res);
      this.clientArr = res;
    })
  }

  getProjectData(){
    this.dataservice.getProjectslist().subscribe(res=>{
      //console.log(res);
      this.projectArr = res;
    })
  }

  getSubprojectData(){
    this.dataservice.getSubprojectslist1().subscribe(res=>{
      //console.log(res);
      this.subprojectsArr = res;
    })
  }

  // getState(event){
  //   var obj = {
  //     project_id : event.target.value
  //   }

  //   this.dataservice.getSubprojectslist(obj).subscribe(res => {
  //             this.subprojectsArr = res;
  //   });
  // }

  getBookingstatusData(){
    this.dataservice.getBookingstatusList().subscribe(res=>{
      //console.log(res);
      this.bookingstatusArr = res;
    });
  }

  getChannelpartnerData(){
    this.dataservice.getChannelpartnerList().subscribe(res=>{
      //console.log(res);
      this.channelpartnerArr = res;
    });
  }

  getPayoutstatusData(){
    this.dataservice.getPayoutstatusList().subscribe(res=>{
      //console.log(res);
      this.payoutstatusArr = res;
    });
  }

  getUserData(){
    this.dataservice.getUserslist().subscribe(res=>{
      this.usersArr = res;
    })
  }

  getTeamsData(){
    this.dataservice.getTeamslist().subscribe(res=>{
      this.teamsArr = res;
    })
  }

  getLeadsourceData(){
    this.dataservice.getLeadsourceList().subscribe(res=>{
      this.leadsourceArr = res;
    })
  }

  getDate(event){
  
    this.booking_date = event.target.value
    //console.log(this.booking_date);

    //Add days to Issue Date      
    this.newDate1 = moment(new Date(this.booking_date)).add(45,'d');
    //console.log(new Date(this.newDate));
    console.log(this.datePipe.transform(new Date(this.newDate1),"yyyy-MM-dd"));

    this.salesdetails.BA1_amt_paid = this.datePipe.transform(new Date(this.newDate1),"yyyy-MM-dd");


    //Add days to Issue Date      
    this.newDate2 = moment(new Date(this.booking_date)).add(90,'d');
    //console.log(new Date(this.newDate));
    console.log(this.datePipe.transform(new Date(this.newDate2),"yyyy-MM-dd"));

    this.salesdetails.BA2_amt_paid = this.datePipe.transform(new Date(this.newDate2),"yyyy-MM-dd");
}

  updateSalesdetails(){
    this.dataservice.updateSalesdetails(this.salesdetailsid,this.salesdetails).subscribe(res=>{
      //console.log(res);
      Swal.fire('Updated!', 'Sales Details has been updated.', 'success'); 
      this.router.navigate(['/form/salesdetailslist']);
      //console.log(res);
      //this.data=res;
      //this.roles=this.data;
    })
  }

  get bmi() {

    var selectedOption = Number(this.salesdetails.consideration_value) * Number(this.salesdetails.case_payout_percentage) / 100;
    this.salesdetails.payout_value = Number(this.salesdetails.consideration_value) * Number(this.salesdetails.case_payout_percentage) / 100;
    return  Number(this.salesdetails.consideration_value) * Number(this.salesdetails.case_payout_percentage) / 100;
  }

  get bmi2() {

    var ankita1 = Number(this.salesdetails.consideration_value) * Number(this.salesdetails.extra_payout_percentage) / 100;
    var selectedOption = Number(ankita1) + Number(this.salesdetails.extra_payout_value);
    this.salesdetails.net_extra_payout = Number(ankita1) + Number(this.salesdetails.extra_payout_value);
    return  Number(ankita1) + Number(this.salesdetails.extra_payout_value);
  }

  get bmi3() {

    var ankita2 = Number(this.salesdetails.consideration_value) * Number(this.salesdetails.shared_payout) / 100;
    var selectedOption = Number(ankita2) + Number(this.salesdetails.shared_payout_value);
    this.salesdetails.net_shared_payout = Number(ankita2) + Number(this.salesdetails.shared_payout_value);
    return  Number(ankita2) + Number(this.salesdetails.shared_payout_value);
  }

  get bmi1() {
   
    var ankita = Number(this.salesdetails.payout_value) - Number(this.salesdetails.net_shared_payout) + Number(this.salesdetails.net_extra_payout);
    var selectedOption = Number(this.salesdetails.payout_value) - Number(this.salesdetails.net_shared_payout) + Number(this.salesdetails.net_extra_payout);
    this.salesdetails.net_payout = Number(this.salesdetails.payout_value) - Number(this.salesdetails.net_shared_payout) + Number(this.salesdetails.net_extra_payout);
   return  Number(this.salesdetails.payout_value) - Number(this.salesdetails.net_shared_payout) + Number(this.salesdetails.net_extra_payout);
  }

}
