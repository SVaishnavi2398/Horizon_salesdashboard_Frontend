export class Salarypackage{
    salary_package_id : any;
    user_id  : any;
    from_date : any;
    to_date : any;
    basic_pay : any;
    variable_pay : any;
    yearly_bonus : any;
    monthly_salary : any;
    yearly_salary : any;
    remark : any;
}